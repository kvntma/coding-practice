function solution(S, X, Y) {
  // write your code in JavaScript (Node.js 8.9.4)distances.push[ X[i] + Y[i]]

  const getDistance = (X, Y) => {
    return Math.sqrt(x * x + y * y);
  };

  let distances = [];

  for (i = 0; i < X.length; i++) {
    distances.push(getDistance(x[i], y[i]));
  }
}
