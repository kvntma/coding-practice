const minCoinChange = (coins, amount) => {
  const cache = [];
  const makeChange = (value) => {
    if (!value) {
      return [];
    }
    if (cache[value]) {
      return cache[value];
    }
  };
};

console.log(minCoinChange([1, 5, 10, 25], 36));
