// Implement a function to evaluate an expression string. The expression string may contain the plus + or minus sign -, non-negative integers.
// Assume that the given expression is always valid.

// Examples =>
// "2" = 2
// "2+3" = 5
// "3-5" = -2
// "2-7+3" = -2
// "200 - 100 - 500" = 100
// Note: Do not use the built-in library functions like eval(python) etc.

//pseudocode
//do steps write down and then convert it into code

const arithmetic = (s) => {
  let stringArray = s.split("");
  console.log(stringArray);
  let currentString = "";
  let currentNumber = 0;
  let operator = true;

  const parseString = (currentString) => {
    return parseInt(currentString);
  };

  console.log(parseString("2421"));

  for (let i = 0; i < stringArray; i++) {
    if (stringArray[i] == "-" || (stringArray[i] == "+" && operator == true)) {
      currentNumber += parseString(currentString);
      currentString = "";

      // do check inside here operator

      //transfer if state check here
    }
    //     } else if ((stringArray[i] == '-' || (stringArray[i] == '+') && operator == false)) {
    //       currentNumber -= parseString(currentString);
    //       currentString = ""
    //   }

    //} else {
    console.log(currentString);
    currentString += s[i];
    //}
  }

  if (currentString && operator == true) {
    currentNumber += parseString(currentString);
  } else {
    currentNumber -= parseString(currentString);
  }
  console.log(currentNumber);
  return currentNumber;
};

console.log(arithmetic("2-7+3"));
