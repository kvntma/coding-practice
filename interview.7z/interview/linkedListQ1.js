const input = ["P>E", "R>U", "E>R"];

let arrayed = [];
let ans = "";

input.forEach((element) => arrayed.push(element.split(">")));

const adjList = Object.fromEntries(arrayed); // create a hashMap from the array list

let start = Object.keys(adjList)
  .filter((x) => !Object.values(adjList).includes(x)) // compares keys to value sets and if a key is NOT in values we take that as the start
  .toString(); // converts this value from array to string

while (start in adjList) {
  // we loop through our adjacency list and follow the path until there are no more keys.
  ans += start;
  start = adjList[start];
}

console.log(
  ans + Object.values(adjList).filter((x) => !Object.keys(adjList).includes(x)) // answer + last letter (because last letter not printed)
);
