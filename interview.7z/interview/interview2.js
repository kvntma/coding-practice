/* 

Given a set of integers, e.g. {1,3,2}, and an array of random integers, e.g. 
[1, 2, 2, -5, -4, 0, 1, 1, 2, 2, 0, 3,3]
       l
                     r
        
1 : 3 <-- "true"
2 : 2 <-- "false"
3 : 1 



Find the shortest continuous subarray that contains all of the values from the set. If the subarray can not be found, return an empty array.
Result: [1, 2, 2, 0, 3]

 */

let set = new Set([1, 3, 2]);
let fullArray = [1, 2, 2, -5, -4, 0, 1, 1, 2, 2, 0, 3, 3];

const scs = (set, fullArray) => {
  let res = [];
  let set2 = new Set();
  let currentLength = 0;
  let minimumLength = 0;
  let leftWindow = 0;
  let rightWindow = 0;

  for (let i = 0; i <= fullArray.length; i++) {
    console.log("test");
    if (set.has(fullArray[i])) {
      set2.add(fullArray[i]);
    }
    if (set2.size == set.size) {
      console.log("test");
      let currentArray = fullArray.splice(leftWindow, rightWindow);
      currentLength = currentArray.length;
      console.log(currentLength);
    }

    if (currentLength < minimumLength) {
      minimumLength = currentLength;
      res = currentArray;
    } else {
      leftWindow++;
      set2.delete(fullArray[i]);
    }

    while (rightWindow <= fullArray.length) {
      rightWindow++;
    }
  }
  return res;
};

console.log(scs(set, fullArray));

/*

vankaumnii@gmail.com
https://github.com/donnemartin/system-design-primer
https://github.com/checkcheckzz/system-design-interview

*/
