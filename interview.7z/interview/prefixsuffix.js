const solution = (s) => {
  let longest = 0;

  for (i = 0; i < s.length; i++) {
    let [prefix, suffix] = [s.slice(0, i), s.slice(-i)];
    console.log(prefix);
    console.log(suffix);
    if (prefix == suffix) {
      longest = i;
    }
  }
  return longest;
};

console.log(solution("abbabba"));
