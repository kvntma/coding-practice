let memo = {};
const Memoization = (n) => {
  let value;
  if (memo[n]) {
    return memo[n];
  }
  if (n < 0) {
    value = 0;
  } else if (n == 1) {
    value = 1;
  } else {
    value = Memoization(n - 1) + Memoization(n - 2);
  }
  memo[n] = value;
  return memo[n];
};

console.log(Memoization(30));
