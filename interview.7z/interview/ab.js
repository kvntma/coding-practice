const solution = (A, B) => {
  let res = [];
  let counter = 0;
  let chooseFunc = A >= B;
  if (chooseFunc) {
    while (A + B > 0) {
      if (counter < 2 && A > 0) {
        res.push("a");
        counter++;
        A--;
        console.log(A);
      } else if (A / B < 2) {
        res.push("b");
        res.push("b");
        B--;
        B--;
        counter = 0;
      } else {
        res.push("b");
        counter = 0;
        B--;
      }
    }
  } else {
    while (A + B > 0) {
      if (counter < 2 && B > 0) {
        res.push("b");
        counter++;
        B--;
      } else if (B / A < 2) {
        res.push("a");
        res.push("a");
        A--;
        A--;
        counter = 0;
      } else {
        res.push("a");
        counter = 0;
        A--;
      }
    }
  }
  return res.join("");
};

console.log(solution(20, 9));
