const a = [7, 3, 7, 3, 1, 3, 4, 1];

const solution = (A) => {
  let unique = new Set(A).size; // total number of unique destinations
  let visited = {}; // makes hashmap of destinations as keys and total times visited (must be at least 1)
  let currentShortest = Number.MAX_SAFE_INTEGER; //current lowest days
  let i = 0; //left window
  let j = 0; //right window

  while (j < A.length) {
    //while the right window is less than the array length
    if (!visited[A[j]]) {
      visited[A[j]] = 1;
    } else {
      visited[A[j]] += 1;
    }
    // add to the visited hashmap, increment if already there
    if (unique == Object.keys(visited).length) {
      // once we have visited all the locations at LEAST once, calculate the amount of days it took
      currentShortest = Math.min(currentShortest, j - i + 1); // +1 because 0 index
      while (visited[A[i]] > 1) {
        // now we check, "have we already visited this node more than once? if so we dont need to visit on this day"
        currentShortest = Math.min(currentShortest, j - i);
        // if we are in this while loop it means we can make this window smaller
        if (visited[A[i]] > 1) {
          visited[A[i]] -= 1;
          i++;
          //check next destination in the array to see if we are still in the constraints
        }
      }
    }
    j++; // keep moving
  }
  console.log(A.splice(i, currentShortest));
  return currentShortest;
};

console.log(solution(a));
